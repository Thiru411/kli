<?php

namespace EllisLab\ExpressionEngine\Library\Parser\Conditional\Exception;

use Exception;

class BooleanExpressionException extends Exception {}