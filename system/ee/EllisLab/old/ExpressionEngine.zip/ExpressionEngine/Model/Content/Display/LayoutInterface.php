<?php

namespace EllisLab\ExpressionEngine\Model\Content\Display;

interface LayoutInterface {

	public function transform(array $fields);

}