<?php

namespace EllisLab\ExpressionEngine\Error;

class FileNotFound extends \Exception {}

// EOF
