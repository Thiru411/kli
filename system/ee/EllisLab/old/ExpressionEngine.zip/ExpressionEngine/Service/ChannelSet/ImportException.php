<?php

namespace EllisLab\ExpressionEngine\Service\ChannelSet;

class ImportException extends \Exception {}
