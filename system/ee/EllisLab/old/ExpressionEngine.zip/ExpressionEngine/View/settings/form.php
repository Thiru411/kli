<?php
	$this->extend('_templates/default-nav');
	$this->embed('_shared/form');
?>