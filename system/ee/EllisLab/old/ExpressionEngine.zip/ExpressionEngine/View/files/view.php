<h1><?=$file->file_name?><br><i><?=$width?> x <?=$height?> <?=lang('pixels')?>. <?=$size?></i></h1>
<img src="<?=$file->getAbsoluteURL()?>">
