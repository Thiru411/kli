<?php
	$this->extend('_templates/default-nav', array(), 'outer_box');
?>
<div class="box">
	<?php $this->embed('_shared/form'); ?>
</div>
