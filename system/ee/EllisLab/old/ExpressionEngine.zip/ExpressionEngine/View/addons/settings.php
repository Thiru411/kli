<?php $this->extend('_templates/default-nav', array(), 'outer_box'); ?>

<?=$_module_cp_body?>
